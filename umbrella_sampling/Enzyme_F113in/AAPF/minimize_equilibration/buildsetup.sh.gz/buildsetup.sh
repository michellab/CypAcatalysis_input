gmx=/home/pattama/local/gromacs/bin

$gmx'/pdb2gmx' -f transAAPF.pdb -o AAPF_processed.gro -water tip3p -ignh -ff amber99sb_modified 

$gmx'/editconf' -f AAPF_processed.gro -o AAPF_newbox.gro -c -d 1.0 -bt dodecahedron

$gmx/gmx solvate -cp AAPF_newbox.gro -cs spc216.gro -o AAPF_solv.gro -p topol.top

$gmx'/grompp' -f ions.mdp -c AAPF_solv.gro -p topol.top -o ions.tpr

echo SOL | $gmx'/genion' -s ions.tpr -o AAPF_solv_ions.gro -p topol.top -pname NA -nname CL -neutral

$gmx'/grompp' -f minim.mdp -c AAPF_solv_ions.gro -p topol.top -o em.tpr

$gmx'/mdrun' -v -deffnm em


$gmx'/grompp' -f nvt.mdp -c em.gro -p topol.top -o nvt.tpr

$gmx'/mdrun' -v -deffnm nvt  -ntomp 8 -gpu_id 1 -pin on -pinoffset 0


$gmx'/grompp' -f npt.mdp -c nvt.gro -p topol.top -o npt.tpr
$gmx'/mdrun' -v -deffnm npt -ntomp 8 -gpu_id 1 -pin on -pinoffset 0
