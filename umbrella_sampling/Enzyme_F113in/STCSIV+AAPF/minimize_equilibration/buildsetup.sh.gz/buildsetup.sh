gmx=/home/pattama/local/gromacs/bin

$gmx'/pdb2gmx' -f 5wc7M_cisAAPF.pdb -o 5wc7M_processed.gro -water tip3p -ignh -ff amber99sb_modified  -ter -his

$gmx'/editconf' -f 5wc7M_processed.gro -o 5wc7M_newbox.gro -c -d 1.0 -bt dodecahedron

$gmx/gmx solvate -cp 5wc7M_newbox.gro -cs spc216.gro -o 5wc7M_solv.gro -p topol.top

$gmx'/grompp' -f ions.mdp -c 5wc7M_solv.gro -p topol.top -o ions.tpr

echo SOL | $gmx'/genion' -s ions.tpr -o 5wc7M_solv_ions.gro -p topol.top -pname NA -nname CL -neutral

$gmx'/grompp' -f minim.mdp -c 5wc7M_solv_ions.gro -p topol.top -o em.tpr

$gmx'/mdrun' -v -deffnm em


$gmx'/grompp' -f nvt.mdp -c em.gro -p topol.top -o nvt.tpr

$gmx'/mdrun' -v -deffnm nvt  -ntomp 1 -gpu_id 0 -pin off -pinoffset 1


$gmx'/grompp' -f npt.mdp -c nvt.gro -p topol.top -o npt.tpr
$gmx'/mdrun' -v -deffnm npt -ntomp 1 -gpu_id 0 -pin off -pinoffset 1
